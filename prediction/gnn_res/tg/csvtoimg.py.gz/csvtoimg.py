from matplotlib import pyplot as plt
import numpy as np
import pandas as pd

open_file = './rnn/result_rnn_tgc.csv'
tasks = ['tg']
metrics = ['test_rmse','test_r2']
def sep(s):
    point,range = [],[]
    for val in s:
        vals = val.split("±")
        point.append(float(vals[0]))
        range.append(float(vals[1]))
    return point,range


test_repeat_time = [1,2,3,4,5,6,7,8,9,10]
if __name__=='__main__':
    df = pd.read_csv(open_file)
    group_df = df.groupby('train_repeat_time')
    print(group_df)
    num_of_train_repeat_time = 10
    #colors = ['blue','orange','pink','green','yellow','','']
    for r in group_df.groups.keys():
    #t = tasks[i]
        save_fig = './imgres/rnn/rnn_res_{}.jpg'.format(r)
        fig, (ax1, ax2) = plt.subplots(2)
        fig.suptitle('tg property of RNN model trained with {} RU'.format(r))
    
        gp1 = group_df.get_group(r)[metrics[0]].to_list()
        gp_point_rmse,gp_range_rmse = sep(gp1)
        #rmse_indx=np.argmin(gp_point_rmse) #min rmse value index
        rmse_indx = 8
        ax1.errorbar(test_repeat_time,gp_point_rmse,yerr=gp_range_rmse,fmt='o-',capsize=1)
        
        #show_min='min rmse: ['+str(rmse_indx+1)+', '+str(gp_point_rmse[rmse_indx])+']'
        show_min='min rmse: [1, '+str(gp_point_rmse[rmse_indx])+']'
        ax1.plot(rmse_indx+1,gp_point_rmse[rmse_indx],color='r',marker = 's',markersize = 7,zorder=5,label = show_min)
        ax1.annotate('',xytext=(rmse_indx+1,gp_point_rmse[rmse_indx]+10),xy=(rmse_indx+1,gp_point_rmse[rmse_indx]))
        ax1.set_ylabel('{}'.format(metrics[0])) #设置y轴名称 y label
        ax1.legend() #自动检测要在图例中显示的元素，并且显示

        gp2 = group_df.get_group(r)[metrics[1]].to_list()
        gp_point_r2,gp_range_r2 = sep(gp2)
        r2_indx=np.argmax(gp2) #max r2 value index
        ax2.errorbar(test_repeat_time,gp_point_r2,yerr=gp_range_r2,fmt='o-',c='orange',capsize=1)
        
        show_max='max r2: ['+str(r2_indx+1)+', '+str(gp_point_r2[r2_indx])+']'
        ax2.plot(r2_indx+1,gp_point_r2[r2_indx],color='r',marker = 's',markersize = 7,zorder=5,label = show_max)
        ax2.annotate('',xytext=(r2_indx+1,gp_point_r2[r2_indx]-0.1),xy=(r2_indx+1,gp_point_r2[r2_indx]))
        
        ax2.set_xlabel('test repeat times') #设置x轴名称 x label
        ax2.set_ylabel('{}'.format(metrics[1])) #设置y轴名称 y label
        ax2.legend() #自动检测要在图例中显示的元素，并且显示

        plt.savefig(save_fig)
        '''

            gp,test_repeat_time = group_df.get_group(r)[m].to_list(), group_df.get_group(r)['test_repeat_time'].to_list()

            gp_point,gp_range = sep(gp)
            ax.errorbar(test_repeat_time,gp_point,yerr=gp_range,fmt='o-',capsize=1)
        ax.set_xlabel('test repeat times') #设置x轴名称 x label
        ax.set_ylabel('{}'.format(m)) #设置y轴名称 y label
        ax.set_title('GCN {} for tg property').format(m) #设置图名为Simple Plot
        ax.legend() #自动检测要在图例中显示的元素，并且显示

            
        plt.savefig(save_fig)

        '''